﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TaskNewForm
{
    public partial class ResetPassword : Form      
    {
        private static string Connectionstring = DbConnection.DbCon();
        public static SqlConnection con = new SqlConnection(Connectionstring);

        string email = SendCode.to;
        public ResetPassword()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            LoginForm fm1 = new LoginForm();
            this.Hide();
            fm1.Show();
        }

        private void ResetPassword_Load(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            if (txtEmail.Text == "") 
            {
                MessageBox.Show("Please Enter Email");
                return;
            }

            if (txtResetPswrd.Text == "")
            {
                MessageBox.Show("Please Enter New Password");
                return;
            }

            if (txtverifyresetpswrd.Text == "")
            {
                MessageBox.Show("Please Enter Confirm password");
                return;
            }

            string email, password;
            email = txtEmail.Text;
            password = txtResetPswrd.Text;

            if (txtResetPswrd.Text == txtverifyresetpswrd.Text)
            {
                string Sql = "update [tblGen_Info] set [Password] ='" + password + "' where Email='" + email + "'";

                con.Open();
                SqlCommand cmd = new SqlCommand(Sql, con);
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("Password Successfully Changed");
                }
                else 
                {
                    MessageBox.Show("Sorry Yuor details are wrong");
                }
                con.Close();

            }

            else
            {
                MessageBox.Show("Sorry your New Password and Confirm Password is not match");
            }
           

        }
    }
}
