﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;


namespace TaskNewForm
{
    public partial class LoginForm : Form
    {

        

        private static string Connectionstring1 = DbConnection.DbCon();
        public static SqlConnection con = new SqlConnection(Connectionstring1);
        public LoginForm()
        {
            InitializeComponent();
        }

       
        
        private void llblNotRegistered_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            RegistrationForm f2 = new RegistrationForm();
            this.Hide();
            f2.Show();
        }

        private void llForgerPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SendCode f3 = new SendCode();
            this.Hide();
            f3.Show();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtEmail.Text == "") 
            {
                MessageBox.Show("Please Enter Email");
                return;
            }

            if (txtPassword.Text == "") 
            {
                MessageBox.Show("Please Enter Password");
                return;
            }

            bool iseq = false;

            string Sql = @"SELECT Email,Password FROM tblGen_Info";
            con.Open();
            SqlCommand cmd = new SqlCommand(Sql, con);
            SqlDataReader read = cmd.ExecuteReader();
            
            while(read.Read())
            {

                string em = read["Email"].ToString();
                string pswd = read["Password"].ToString();
                if (txtEmail.Text.Equals(em) && txtPassword.Text.Equals(pswd)) 
                {
                    iseq = true;
                }
            }
            con.Close();

            if (iseq == true)
            {
                MessageBox.Show("Successfully Login");
                this.Hide();
                Welcome fm4 = new Welcome();
                fm4.Show();
            }

            else if(iseq == false) 
            {
                MessageBox.Show("Invalid LOgin details");

            }
        }

    }
       


            }
           
        
    
 

