﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskNewForm
{
    class DbConnection
    {
        public static string DbCon() {

            string Str = "server = DESKTOP-45M6VAU; user id = sa; database = UserRegistration; password = Spil@123";
            return Str;

        }
    }
}
