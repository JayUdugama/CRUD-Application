﻿
namespace TaskNewForm
{
    partial class ResetPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtResetPswrd = new System.Windows.Forms.TextBox();
            this.lblresetpswrd = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtverifyresetpswrd = new System.Windows.Forms.TextBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtResetPswrd
            // 
            this.txtResetPswrd.Location = new System.Drawing.Point(146, 69);
            this.txtResetPswrd.Name = "txtResetPswrd";
            this.txtResetPswrd.Size = new System.Drawing.Size(142, 20);
            this.txtResetPswrd.TabIndex = 0;
            this.txtResetPswrd.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblresetpswrd
            // 
            this.lblresetpswrd.AutoSize = true;
            this.lblresetpswrd.Location = new System.Drawing.Point(12, 72);
            this.lblresetpswrd.Name = "lblresetpswrd";
            this.lblresetpswrd.Size = new System.Drawing.Size(84, 13);
            this.lblresetpswrd.TabIndex = 1;
            this.lblresetpswrd.Text = "Reset Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Verify reset password";
            // 
            // txtverifyresetpswrd
            // 
            this.txtverifyresetpswrd.Location = new System.Drawing.Point(146, 120);
            this.txtverifyresetpswrd.Name = "txtverifyresetpswrd";
            this.txtverifyresetpswrd.Size = new System.Drawing.Size(142, 20);
            this.txtverifyresetpswrd.TabIndex = 3;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(213, 164);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 4;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(12, 23);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(32, 13);
            this.lblEmail.TabIndex = 5;
            this.lblEmail.Text = "Email";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(146, 20);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(142, 20);
            this.txtEmail.TabIndex = 6;
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(88, 164);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 7;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // ResetPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(312, 218);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.txtverifyresetpswrd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblresetpswrd);
            this.Controls.Add(this.txtResetPswrd);
            this.Name = "ResetPassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reset Password";
            this.Load += new System.EventHandler(this.ResetPassword_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtResetPswrd;
        private System.Windows.Forms.Label lblresetpswrd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtverifyresetpswrd;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Button btnBack;
    }
}