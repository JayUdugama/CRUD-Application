﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;


namespace TaskNewForm
{
    public partial class RegistrationForm : Form
    {
        //database connection
        private static string Connectionstring = DbConnection.DbCon();
        public static SqlConnection con = new SqlConnection(Connectionstring);

        DataSet ds1 = new DataSet();
        DataSet ds2 = new DataSet();
        DataSet ds3 = new DataSet();


        //General Information placeholder
        string NIC = string.Empty;
        string Fname = string.Empty;
        string Lname = string.Empty;
        string Email = string.Empty;
        int Age = 0;
        DateTime DOB = DateTime.Now;
        bool IsMarried = false;
        string Pswrd = string.Empty;
        string CnfrmPswrd = string.Empty;

        //Residential information placeholder
        string Add1 = string.Empty;
        string Add2 = string.Empty;
        string Add3 = string.Empty;
        string City = string.Empty;
        string Province = string.Empty;
        string ContactNo = string.Empty;

        //Parents Information placeholder
        string FatherName = string.Empty;
        string MotherName = string.Empty;
        string ContactNo1 = string.Empty;
        string Add11 = string.Empty;
        string Add22 = string.Empty;
        string Add33 = string.Empty;
        string City1 = string.Empty;
        string Province1 = string.Empty;

      


        public RegistrationForm()
        {
            InitializeComponent();
        }

        public void LoadData1()
        {

            string strLoaddta1 = "SELECT NIC , First_Name , Last_Name , Email , Password , Confirm_Password , Age , Date_Of_Birth ,Marital_Status FROM tblGen_Info";
            con.Open();
            SqlDataAdapter Adp = new SqlDataAdapter(strLoaddta1, con);
            Adp.Fill(ds1);
            dgv1.DataSource = ds1.Tables[0];
            con.Close();

        }

        public void LoadData2()
        {

            string strLoaddta1 = "SELECT Address_1 , Address_2 , Address_3 , City , Province , Contact_Number FROM tblRes_Info";
            con.Open();
            SqlDataAdapter Adp = new SqlDataAdapter(strLoaddta1, con);
            Adp.Fill(ds2);
            dgv2.DataSource = ds2.Tables[0];
            con.Close();

        }

        public void LoadData3()
        {

            string strLoaddta1 = "SELECT Fathers_Name , Mothers_Name , Contact_No , Address_1 , Address_2 , Address_3 , City , Province FROM tblParen_Info ";
            con.Open();
            SqlDataAdapter Adp = new SqlDataAdapter(strLoaddta1, con);
            Adp.Fill(ds3);
            dgv3.DataSource = ds3.Tables[0];
            con.Close();

        }

        public void ClearText()
        {
            //General Information
            txtNIC.Clear();
            txtFirstName.Clear();
            txtLastName.Clear();
            txtEmail.Clear();
            Age = 0;
            DOB = DateTime.MinValue;
            txtPassword.Clear();
            txtConfirmPassword.Clear();

            //Residential information placeholder
            string Add1 = string.Empty;
            string Add2 = string.Empty;
            string Add3 = string.Empty;
            string City = string.Empty;
            string Province = string.Empty;
            string ContactNo = string.Empty;

            //Parents Information placeholder
            string FatherName = string.Empty;
            string MotherName = string.Empty;
            string ContactNo1 = string.Empty;
            string Add11 = string.Empty;
            string Add22 = string.Empty;
            string Add33 = string.Empty;
            string City1 = string.Empty;
            string Province1 = string.Empty;



        }

        private void txtAge_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData1();
            LoadData2();
            LoadData3();

        }

        private void btnSave1_Click(object sender, EventArgs e)
        {
            try
            {

                NIC = txtNIC.Text;
                Fname = txtFirstName.Text;
                Lname = txtLastName.Text;
                Email = txtEmail.Text;
                Age = Convert.ToInt32(nudAge.Value);
                DOB = dtpDOB.Value;
                Pswrd = txtPassword.Text;
                CnfrmPswrd = txtConfirmPassword.Text;
                if (rbMarried.Checked == true)
                {
                    IsMarried = true;
                }
                else if (rbUnmarried.Checked == false)
                {
                    IsMarried = false;
                }



                if (!string.IsNullOrEmpty(NIC) && !string.IsNullOrEmpty(Fname) && !string.IsNullOrEmpty(Lname)
                    && !string.IsNullOrEmpty(Email) && !string.IsNullOrEmpty(Pswrd) && !string.IsNullOrEmpty(CnfrmPswrd)
                    && Age > 0 && dtpDOB != null)

                {
                    string Sql = " INSERT INTO tblGen_Info( NIC , First_Name , Last_Name , Email , Password , Confirm_Password , Age , Date_Of_Birth , Marital_Status) "

                                           + " VALUES ('" + NIC + "' ,'" + Fname + "' , '" + Lname + "' ,'" + Email + "'" +
                                           " , '" + Pswrd + "' ,'" + CnfrmPswrd + "' , '" + Age + "' ,'" + DOB + "' , '" + IsMarried + "'  ) ";

                    con.Open();
                    SqlCommand cmd = new SqlCommand(Sql, con);
                    cmd.ExecuteNonQuery();
                    ClearText();
                    txtNIC.Focus();
                    MessageBox.Show("Data Added successfully..!!");
                    con.Close();
                    LoadData1();

                }
                else

                {
                    MessageBox.Show("Please Fill all the data!", "Ërror", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

            }
            catch (Exception ex)
            {
                throw ex;

            }



        }

        private void btnSave2_Click(object sender, EventArgs e)
        {
            try
            {

                Add1 = txtAdd1.Text;
                Add2 = txtAdd2.Text;
                Add3 = txtAdd3.Text;
                City = txtCity.Text;
                Province = cbProvince.SelectedItem.ToString();
                ContactNo = txtContactNo.Text;

                if (!string.IsNullOrEmpty(Add1) && !string.IsNullOrEmpty(Add2) && !string.IsNullOrEmpty(Add3)
                    && !string.IsNullOrEmpty(City) && !string.IsNullOrEmpty(Province) && !string.IsNullOrEmpty(ContactNo)
                   )

                {

                    string Sql = "  INSERT INTO tblRes_Info( Address_1 , Address_2 , Address_3 , City , Province , Contact_Number )"

                           + " VALUES ('" + Add1 + "' ,'" + Add2 + "' , '" + Add3 + "' ,'" + City + "'" +
                           "  ,'" + Province + "' , '" + ContactNo + "'   ) ";

                    con.Open();
                    SqlCommand cmd = new SqlCommand(Sql, con);
                    cmd.ExecuteNonQuery();
                    ClearText();
                    txtAdd1.Focus();
                    MessageBox.Show("Data Added successfully..!!");
                    con.Close();
                    LoadData2();

                }
                else

                {
                    MessageBox.Show("Please Fill all the data!", "Ërror", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

            }
            catch (Exception ex)
            {
                throw ex;

            }

        }

        private void btnSave3_Click(object sender, EventArgs e)
        {
            try
            {
                FatherName = txtFatherName.Text;
                MotherName = txtMotherName.Text;
                ContactNo1 = txtContactNo1.Text;
                Add11 = txtAdd11.Text;
                Add22 = txtAdd22.Text;
                Add33 = txtAdd33.Text;
                City1 = txtCity1.Text;
                Province1 = cbProvince1.SelectedItem.ToString();



                if (!string.IsNullOrEmpty(FatherName) && !string.IsNullOrEmpty(MotherName) && !string.IsNullOrEmpty(ContactNo1)
                    && !string.IsNullOrEmpty(Add11) && !string.IsNullOrEmpty(Add22) && !string.IsNullOrEmpty(Add33)
                    && !string.IsNullOrEmpty(City1) && !string.IsNullOrEmpty(Province1))

                {
                    string Sql = " INSERT INTO tblParen_Info (Fathers_Name , Mothers_Name , Contact_No , Address_1 , Address_2 , Address_3 , City , Province ) "

                                           + " VALUES ('" + FatherName + "' ,'" + MotherName + "' , '" + ContactNo1 + "' ,'" + Add11 + "'" +
                                           " , '" + Add22 + "' ,'" + Add33 + "' , '" + City1 + "' ,'" + Province1 + "'  ) ";

                    con.Open();
                    SqlCommand cmd = new SqlCommand(Sql, con);
                    cmd.ExecuteNonQuery();
                    ClearText();
                    txtNIC.Focus();
                    MessageBox.Show("Data Added successfully..!!");
                    con.Close();
                    LoadData3();

                }
                else

                {
                    MessageBox.Show("Please Fill all the data!", "Ërror", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

            }
            catch (Exception ex)
            {
                throw ex;

            }

        }

        private void btnUpdate1_Click(object sender, EventArgs e)
        {
            try
            {
                NIC = txtNIC.Text;
                Fname = txtFirstName.Text;
                Lname = txtLastName.Text;
                Email = txtEmail.Text;
                Age = Convert.ToInt32(nudAge.Text);
                DOB = dtpDOB.Value;
                Pswrd = txtPassword.Text;
                CnfrmPswrd = txtConfirmPassword.Text;
                if (rbMarried.Checked == true)
                {
                    IsMarried = true;
                }
                else if (rbUnmarried.Checked == false)
                {
                    IsMarried = false;
                }


                if (!string.IsNullOrEmpty(NIC) && !string.IsNullOrEmpty(Fname) && !string.IsNullOrEmpty(Lname)
                && !string.IsNullOrEmpty(Email) && !string.IsNullOrEmpty(Pswrd) && !string.IsNullOrEmpty(CnfrmPswrd)
                && Age >= 0 && dtpDOB != null)

                {

                    string Sql = "UPDATE tblGen_Info SET NIC = '" + NIC + "' , First_Name = '" + Fname + "', Last_Name = '" + Lname + "', Email ='" + Email + "', Password = '" + Pswrd + "',Confirm_Password = '" + CnfrmPswrd + "' , Marital_Status = '" + IsMarried + "' WHERE NIC = '" + NIC + "' ";
                    con.Open();
                    SqlCommand Cmd = new SqlCommand(Sql, con);
                    Cmd.ExecuteNonQuery();
                    ClearText();
                    txtNIC.Focus();
                    MessageBox.Show("Data updated successfully!");
                    con.Close();
                    LoadData1();
                }
                else
                {
                    MessageBox.Show("Please Fill all the data!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }



        }

        private void btnUpdate2_Click(object sender, EventArgs e)
        {
            try
            {
                Add1 = txtAdd1.Text;
                Add2 = txtAdd2.Text;
                Add3 = txtAdd3.Text;
                City = txtCity.Text;
                Province = cbProvince.SelectedItem.ToString();
                ContactNo = txtContactNo.Text;

                if (!string.IsNullOrEmpty(Add1) && !string.IsNullOrEmpty(Add2) && !string.IsNullOrEmpty(Add3)
                && !string.IsNullOrEmpty(City) && !string.IsNullOrEmpty(Province) && !string.IsNullOrEmpty(ContactNo))

                {

                    string Sql = "UPDATE  SET Address_1 = '" + Add1 + "' , Address_2 = '" + Add2 + "', Address_3 = '" + Add3 + "', City ='" + City + "', Province = '" + Province + "',Contact_Number = '" + ContactNo + "' , Marital_Status = '" + IsMarried + "' ";
                    con.Open();
                    SqlCommand Cmd = new SqlCommand(Sql, con);
                    Cmd.ExecuteNonQuery();
                    ClearText();
                    txtNIC.Focus();
                    MessageBox.Show("Data updated successfully!");
                    con.Close();
                    LoadData2();
                }
                else
                {
                    MessageBox.Show("Please Fill all the data!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        private void btnUpdate3_Click(object sender, EventArgs e)
        {
            try
            {
                FatherName = txtFatherName.Text;
                MotherName = txtMotherName.Text;
                ContactNo1 = txtContactNo1.Text;
                Add11 = txtAdd11.Text;
                Add22 = txtAdd22.Text;
                Add33 = txtAdd33.Text;
                City1 = txtCity1.Text;
                Province1 = cbProvince1.SelectedItem.ToString();

                if (!string.IsNullOrEmpty(FatherName) && !string.IsNullOrEmpty(MotherName) && !string.IsNullOrEmpty(ContactNo1)
                && !string.IsNullOrEmpty(Add11) && !string.IsNullOrEmpty(Add22) && !string.IsNullOrEmpty(Add33) && !string.IsNullOrEmpty(City1) && !string.IsNullOrEmpty(Province1))

                {

                    string Sql = "UPDATE  SET Fathes_Name = '" + FatherName + "' , Mothers_Name = '" + MotherName + "', Contact_No = '" + ContactNo1 + "', Address_1 ='" + Add11 + "', Address_2 = '" + Add22 + "',Address_3 = '" + Add33 + "' , City = '" + City1 + "'  , Province = '" + Province1 + "' ";
                    con.Open();
                    SqlCommand Cmd = new SqlCommand(Sql, con);
                    Cmd.ExecuteNonQuery();
                    ClearText();
                    txtNIC.Focus();
                    MessageBox.Show("Data updated successfully!");
                    con.Close();
                    LoadData2();
                }
                else
                {
                    MessageBox.Show("Please Fill all the data!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        

        private void btnLoad1_Click(object sender, EventArgs e)
        {
            if (dgv1.SelectedRows.Count > 0)
            {
                string IdNic = dgv1.SelectedRows[0].Cells["NIC"].Value.ToString();
                string strLoad = "SELECT NIC, First_Name, Last_Name, Email, Password, Confirm_Password, Age, Date_Of_Birth, Marital_Status FROM tblGen_Info WHERE NIC = '" + IdNic + "'";
                con.Open();
                SqlCommand sqlCommand = new SqlCommand(strLoad, con);
                SqlDataReader dr;
                dr = sqlCommand.ExecuteReader();
                if (dr.Read())
                {
                    txtNIC.Text = IdNic;
                    txtFirstName.Text = dr["First_Name"].ToString();
                    txtLastName.Text = dr["Last_Name"].ToString();
                    txtEmail.Text = dr["Email"].ToString();
                    txtPassword.Text = dr["Password"].ToString();
                    txtConfirmPassword.Text = dr["Confirm_Password"].ToString();

                    if (dr["Date_Of_Birth"] != DBNull.Value)
                    {
                        DateTime dob = (DateTime)dr["Date_Of_Birth"];
                        dtpDOB.Value = dob;
                    }

                    if (dr["Age"] != DBNull.Value)
                    {
                        int age = (int)dr["Age"];
                        nudAge.Value = age;
                    }

                    if (dr["Marital_Status"] != DBNull.Value)
                    {
                        bool isMarried = (bool)dr["Marital_Status"];

                        rbMarried.Checked = isMarried;
                        rbUnmarried.Checked = !isMarried;
                    }
                }
                dr.Close();
                con.Close();
            }
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtConfirmPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNIC_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNIC.Text) == true)
            {
                txtNIC.Focus();
                errorProvider1.SetError(this.txtNIC, "Pls fill the NIC");
            }
            else

            {
                errorProvider1.Clear();
            }
        }

        private void txtNIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (char.IsDigit(ch) == true)
            {
                e.Handled = false;

            }
            else if (ch == 8) 
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtFirstName_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtFirstName.Text) == true)
            {
                txtFirstName.Focus();
                errorProvider2.SetError(this.txtFirstName, "Pls fill the Name");
            }
            else

            {
                errorProvider2.Clear();
            }

        }

        private void txtFirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (char.IsLetter(ch) == true)
            {
                e.Handled = false;

            }
            else if (ch == 8)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void nudAge_Leave(object sender, EventArgs e)
        {
            if (nudAge.Value == 0)
            {
                nudAge.Focus();
                errorProvider3.SetError(this.nudAge, "Pls fill the Age");
            }
            else

            {
                errorProvider3.Clear();
            }




        }

        private void txtEmail_Leave(object sender, EventArgs e)

        {
            string emailpattern = "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$";

            if (Regex.IsMatch(txtEmail.Text, emailpattern) == false)
            {
                txtEmail.Focus();
                errorProvider4.SetError(this.txtEmail, "Pls provide the valid email");
            }
            else
            {
                errorProvider4.Clear();
            }
            
        }

        private void txtPassword_Leave(object sender, EventArgs e)

        {
            string pswrdpattern = @"^(?=.*[A-Za-z])(?=.*\d).{8,}$"; // Password pattern: at least 8 characters with one letter and one digit

            if (!Regex.IsMatch(txtPassword.Text, pswrdpattern))
            {
                txtPassword.Focus();
                errorProvider5.SetError(txtPassword, "Password must be at least 8 characters long and contain at least one letter and one digit.");
            }
            else
            {
                errorProvider5.Clear();
            }


        }

        private void txtConfirmPassword_Leave(object sender, EventArgs e)
        {
            if (txtPassword.Text != txtConfirmPassword.Text)
            {
                txtConfirmPassword.Focus();
                errorProvider6.SetError(this.txtConfirmPassword, "Password mismatch");
            }
            else 
            {
                errorProvider6.Clear();
            }
        }

        private void llAlreadyhaveaccount_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LoginForm fm1 = new LoginForm();
            this.Hide();
            fm1.Show();
        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLoad2_Click(object sender, EventArgs e)
        {
            if (dgv2.SelectedRows.Count > 0)
            {
                string Ad1 = dgv2.SelectedRows[0].Cells["Address_1"].Value.ToString();
                string strLoad = "SELECT Address_1, Address_2, Address_3, City, Province, Contact_Number FROM tblRes_Info";
                con.Open();
                SqlCommand sqlCommand = new SqlCommand(strLoad, con);
                SqlDataReader dr;
                dr = sqlCommand.ExecuteReader();
                if (dr.Read())
                {
                    txtAdd1.Text = Ad1;
                    txtAdd2.Text = dr["Address_1"].ToString();
                    txtAdd3.Text = dr["Address_2"].ToString();
                    txtCity.Text = dr["Address_3"].ToString();
                    txtContactNo.Text = dr["Contact_Number"].ToString();
                }
                

                cbProvince.Items.Clear(); // Clear existing items in the ComboBox

                List<string> provinceList = new List<string>(); // Create a list to store the provinces

                while (dr.Read())
                {
                    string province = dr["Province"].ToString();
                    provinceList.Add(province); // Add each province to the list
                }

                foreach (string province in provinceList)
                {
                    cbProvince.Items.Add(province); // Populate the ComboBox from the list
                }

                if (cbProvince.Items.Count > 0)
                {
                    cbProvince.SelectedIndex = 0;
                }

                con.Close();
            }
        }

        private void btnLoad3_Click(object sender, EventArgs e)
        {
            if (dgv3.SelectedRows.Count > 0)
            {
                string Fn = dgv3.SelectedRows[0].Cells["Fathers_Name"].Value.ToString();
                string strLoad = "SELECT Fathers_Name , Mothers_Name , Contact_No , Address_1 , Address_2 , Address_3 , City , Province FROM tblParen_Info";
                con.Open();
                SqlCommand sqlCommand = new SqlCommand(strLoad, con);
                SqlDataReader dr;
                dr = sqlCommand.ExecuteReader();
                if (dr.Read())
                {
                    txtFatherName.Text = Fn;
                    txtMotherName.Text = dr["Mothers_Name"].ToString();
                    txtAdd11.Text = dr["Address_1"].ToString();
                    txtAdd22.Text = dr["Address_2"].ToString();
                    txtAdd33.Text = dr["Address_3"].ToString();
                    txtCity.Text = dr["City"].ToString();
                    txtContactNo.Text = dr["Contact_No"].ToString();
                }


                cbProvince.Items.Clear(); 

                List<string> provinceList = new List<string>(); 

                while (dr.Read())
                {
                    string province = dr["Province"].ToString();
                    provinceList.Add(province); 
                }

                foreach (string province in provinceList)
                {
                    cbProvince.Items.Add(province); // Populate the ComboBox from the list
                }

                if (cbProvince.Items.Count > 0)
                {
                    cbProvince.SelectedIndex = 0;
                }

                con.Close();
            }
        }

        private void btnDelete1_Click(object sender, EventArgs e)
        {
            try
            {
                NIC = txtNIC.Text;
                if (!string.IsNullOrEmpty(NIC))
                {
                    string Sqldel = "DELETE tblGen_Info WHERE NIC = '" + NIC+ "'";
                    con.Open();
                    SqlCommand Cmd = new SqlCommand(Sqldel, con);
                    Cmd.ExecuteNonQuery();
                    ClearText();
                    txtNIC.Focus();
                    MessageBox.Show("Data updated successfully!");
                    con.Close();
                    LoadData1();
                }
                else
                {
                    MessageBox.Show("Please Fill all the data!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void btnDelete2_Click(object sender, EventArgs e)
        {
            try
            {
               
                if (!string.IsNullOrEmpty(Add1))
                {
                    string Sqldel = "DELETE tblRes_Info WHERE Address_1 ='"+Add1+"' ";
                    con.Open();
                    SqlCommand Cmd = new SqlCommand(Sqldel, con);
                    Cmd.ExecuteNonQuery();
                    ClearText();
                    txtNIC.Focus();
                    MessageBox.Show("Data updated successfully!");
                    con.Close();
                    LoadData2();
                }
                else
                {
                    MessageBox.Show("Please Fill all the data!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {

                if (!string.IsNullOrEmpty(FatherName))
                {
                    string Sqldel = "DELETEtblParen_Info WHERE Fathers_Name = '"+ FatherName+"'  ";
                    con.Open();
                    SqlCommand Cmd = new SqlCommand(Sqldel, con);
                    Cmd.ExecuteNonQuery();
                    ClearText();
                    txtNIC.Focus();
                    MessageBox.Show("Data updated successfully!");
                    con.Close();
                    LoadData2();
                }
                else
                {
                    MessageBox.Show("Please Fill all the data!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

}




